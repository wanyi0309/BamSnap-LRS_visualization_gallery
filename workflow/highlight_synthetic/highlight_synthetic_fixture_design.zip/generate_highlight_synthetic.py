#!/usr/bin/env python3
"""Generate deterministic synthetic FASTA/VCF/BAM fixtures for BamSnap-LRS Highlight validation.

Requires: pysam
Inputs (default: same directory as this script):
  highlight_synthetic_variants.tsv
  highlight_synthetic_reads.tsv
  highlight_synthetic_regions.bed
Outputs:
  highlight_synthetic.fa (+ .fai)
  highlight_synthetic.vcf.gz (+ .tbi)
  highlight_synthetic.bam (+ .bai)

Coordinates in the design TSV are explicit:
  variants.tsv pos1 / overrides_1based / lowq_pos1 are 1-based genomic positions.
  reads.tsv start0 is 0-based BAM reference_start.
"""
from __future__ import annotations

import argparse
import csv
import os
import re
from pathlib import Path

try:
    import pysam
except ImportError as e:
    raise SystemExit("This generator requires pysam (the BamSnap-LRS environment should already provide it).") from e

CIGAR_RE = re.compile(r"(\d+)([MIDNSHP=X])")
QUERY_CONSUME = set("MIS=X")
REF_CONSUME = set("MDN=X")


def read_tsv(path: Path):
    with path.open(newline="") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def parse_overrides(text: str):
    out = {}
    if not text or text == ".":
        return out
    for item in text.split(";"):
        pos, base = item.split("=", 1)
        out[int(pos) - 1] = base.upper()
    return out


def parse_pos_list(text: str):
    if not text or text == ".":
        return set()
    return {int(x) - 1 for x in text.split(";") if x}


def cigar_ops(cigar: str):
    ops = [(int(n), op) for n, op in CIGAR_RE.findall(cigar)]
    if not ops or "".join(f"{n}{op}" for n, op in ops) != cigar:
        raise ValueError(f"Invalid CIGAR: {cigar}")
    return ops


def set_ref_allele(ref, pos0: int, allele: str, source: str):
    for j, b in enumerate(allele.upper()):
        p = pos0 + j
        old = ref[p]
        if old != "N" and old != b:
            raise ValueError(
                f"Conflicting REF definitions at chrSYN:{p+1}: existing={old}, new={b} ({source})"
            )
        ref[p] = b


def make_reference(variants, length=2300):
    # N initially lets overlapping VCF REF alleles define the sequence without accidental conflict.
    ref = ["N"] * length
    for row in variants:
        pos0 = int(row["pos1"]) - 1
        set_ref_allele(ref, pos0, row["ref"], f"{row['fixture_id']}:{row['pos1']}")
    # Fill all unspecified sequence deterministically.
    cycle = "ACGT"
    for i, b in enumerate(ref):
        if b == "N":
            ref[i] = cycle[i % 4]
    return "".join(ref)


def write_fasta(path: Path, refseq: str):
    with path.open("w") as fh:
        fh.write(">chrSYN\n")
        for i in range(0, len(refseq), 80):
            fh.write(refseq[i:i+80] + "\n")
    pysam.faidx(str(path))


def sample_field(gt: str, ps: str):
    gt = gt or "./."
    ps = ps or "."
    return f"{gt}:{ps}"


def write_vcf(out_plain: Path, variants, refseq: str):
    with out_plain.open("w") as fh:
        fh.write("##fileformat=VCFv4.2\n")
        fh.write(f"##contig=<ID=chrSYN,length={len(refseq)}>\n")
        fh.write('##FORMAT=<ID=GT,Number=1,Type=String,Description="Genotype">\n')
        fh.write('##FORMAT=<ID=PS,Number=1,Type=Integer,Description="Phase set">\n')
        fh.write("#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\tS2\n")
        for i, row in enumerate(sorted(variants, key=lambda r: (r["chrom"], int(r["pos1"]))), 1):
            fh.write("\t".join([
                row["chrom"], row["pos1"], f"{row['fixture_id']}_{i}", row["ref"], row["alt"],
                ".", "PASS", f"FIXTURE={row['fixture_id']}", "GT:PS",
                sample_field(row["S1_GT"], row["S1_PS"]),
                sample_field(row["S2_GT"], row["S2_PS"]),
            ]) + "\n")


def build_query(refseq: str, start0: int, cigar: str, overrides, insert_seqs):
    refpos = start0
    seq = []
    refpos_for_query_index = []
    ins_iter = iter(insert_seqs)
    for n, op in cigar_ops(cigar):
        if op in "M=X":
            for _ in range(n):
                base = overrides.get(refpos, refseq[refpos])
                if len(base) != 1:
                    raise ValueError(f"Override at {refpos+1} must be one base, got {base!r}")
                seq.append(base)
                refpos_for_query_index.append(refpos)
                refpos += 1
        elif op == "I":
            try:
                ins = next(ins_iter)
            except StopIteration:
                ins = "T" * n
            if len(ins) != n:
                raise ValueError(f"Insertion sequence {ins!r} length != CIGAR I length {n}")
            seq.extend(ins.upper())
            refpos_for_query_index.extend([None] * n)
        elif op in "DN":
            refpos += n
        elif op == "S":
            seq.extend("A" * n)
            refpos_for_query_index.extend([None] * n)
        elif op in "HP":
            pass
        else:
            raise ValueError(f"Unsupported CIGAR op {op}")
    # Ensure there are no extra explicitly supplied insertion sequences.
    try:
        extra = next(ins_iter)
        raise ValueError(f"Unused insertion sequence {extra!r} for CIGAR {cigar}")
    except StopIteration:
        pass
    return "".join(seq), refpos_for_query_index


def write_bam(path: Path, reads, refseq: str):
    header = {"HD": {"VN": "1.6", "SO": "coordinate"}, "SQ": [{"SN": "chrSYN", "LN": len(refseq)}]}
    tmp = path.with_suffix(".unsorted.bam")
    with pysam.AlignmentFile(str(tmp), "wb", header=header) as out:
        for row in reads:
            aln = pysam.AlignedSegment()
            aln.query_name = row["qname"]
            aln.reference_id = 0
            aln.reference_start = int(row["start0"])
            aln.flag = int(row["flag"])
            aln.mapping_quality = int(row["mapq"])
            aln.cigarstring = row["cigar"]
            overrides = parse_overrides(row["overrides_1based"])
            insert_seqs = [] if row["insert_seqs"] in ("", ".") else row["insert_seqs"].split(";")
            seq, q_refpos = build_query(refseq, aln.reference_start, aln.cigarstring, overrides, insert_seqs)
            aln.query_sequence = seq
            quals = [40] * len(seq)
            lowq = parse_pos_list(row["lowq_pos1"])
            for qi, rp in enumerate(q_refpos):
                if rp in lowq:
                    quals[qi] = 2
            aln.query_qualities = quals
            aln.set_tag("FI", row["fixture_id"], value_type="Z")
            aln.set_tag("RI", row["record_id"], value_type="Z")
            out.write(aln)
    pysam.sort("-o", str(path), str(tmp))
    tmp.unlink()
    pysam.index(str(path))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--design-dir", default=None, help="Directory containing the two design TSVs (default: script directory)")
    ap.add_argument("--out-dir", default="highlight_synthetic_out")
    args = ap.parse_args()

    script_dir = Path(__file__).resolve().parent
    design_dir = Path(args.design_dir).resolve() if args.design_dir else script_dir
    out_dir = Path(args.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    variants = read_tsv(design_dir / "highlight_synthetic_variants.tsv")
    reads = read_tsv(design_dir / "highlight_synthetic_reads.tsv")
    refseq = make_reference(variants)

    fa = out_dir / "highlight_synthetic.fa"
    vcf_plain = out_dir / "highlight_synthetic.vcf"
    vcf_gz = out_dir / "highlight_synthetic.vcf.gz"
    bam = out_dir / "highlight_synthetic.bam"
    regions = out_dir / "highlight_synthetic_regions.bed"

    write_fasta(fa, refseq)
    write_vcf(vcf_plain, variants, refseq)
    pysam.tabix_compress(str(vcf_plain), str(vcf_gz), force=True)
    pysam.tabix_index(str(vcf_gz), preset="vcf", force=True)
    vcf_plain.unlink()
    write_bam(bam, reads, refseq)

    src_regions = design_dir / "highlight_synthetic_regions.bed"
    regions.write_text(src_regions.read_text())

    print("Generated:")
    for p in [fa, Path(str(fa)+".fai"), vcf_gz, Path(str(vcf_gz)+".tbi"), bam, Path(str(bam)+".bai"), regions]:
        print(" ", p)
    print("\nSuggested S1 run:")
    print(
        "bamsnap-lrs highlight --highlight-vcf {vcf} --bam {bam} --regions {bed} "
        "--out-prefix plots/SYN.png --fa {fa} --padding 0 --mapq 0 --no-hap-filter "
        "--show-supp --track-title S1".format(vcf=vcf_gz, bam=bam, bed=regions, fa=fa)
    )
    print("\nMultiple-sample run (same BAM interpreted against S1 and S2):")
    print(
        "bamsnap-lrs highlight --highlight-vcf {vcf} --bam {bam} --bam {bam} --regions {bed} "
        "--out-prefix plots/SYN.samples.png --fa {fa} --padding 0 --mapq 0 --no-hap-filter "
        "--show-supp --track-title S1 S2".format(vcf=vcf_gz, bam=bam, bed=regions, fa=fa)
    )


if __name__ == "__main__":
    main()
